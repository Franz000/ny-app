export default{
    database:{
        host: 'localhost',
        user: 'root',
        password: '12345678',
        database: 's_hospital'
    }
}